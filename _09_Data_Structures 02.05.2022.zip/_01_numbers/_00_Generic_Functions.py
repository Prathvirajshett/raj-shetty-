'''
# Generic Functions
---------------------
print()  :  Prints the given value
input()  :  Receives input from end user keyboard
type()   :  Gives type of variable/value
id()     :  Gives address of the variable/value

'''
# REQ: Print value 10 in console

    # Approach 1# Use the value only once
print(10)

    # Approach 2.1# Use the value in 2 or more places
x = 10  # Let us assume x = 10
print(x)
print(x+20)

    # Approach 2.2# Better version of A2
x = 10
print("Value of x : ", x)
print("Addition   : ", x+20)
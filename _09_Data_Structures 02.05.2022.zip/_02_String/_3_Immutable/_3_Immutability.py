x = 100
print(10)
print(10+20)
print(x)
'''Immutable'''
'''
Immutable:  we cannot change objects
-----------
Numbers : int float 
Boolean : bool
String 
Tuple 

Mutable : 
---------
List Dictionary Set
'''
x = 10
print("First  :", x)
x = 20
print("Second :", x)

x = 10
print(x)
x = x + 10
print(x)

msg = 'Hello'
print("Message : ", msg)
msg = 'World'
print("Message : ", msg)

msg = 'Hello'
print("Message : ", msg)
msg = msg + 'World'
print("Message : ", msg)

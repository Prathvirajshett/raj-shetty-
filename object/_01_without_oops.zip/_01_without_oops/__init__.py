class Emp:
    def __init__(self,id):
        pass

    def __init__(self,id,name):
        pass
emp = Emp(10,'afD')
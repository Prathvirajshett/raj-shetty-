if 10 < 20:
    pass




# pass can be used in all blocks
'''
if 
elif 
else 
while 
for 
function blocks 
class 
file handling 
exception handling
'''
print("--------For loop with tuple-------")

list1 = (10, 32, 43, 13, 45, 65, 24, 75, 12)
for num in list1:
    print("Number : ", num)

emp_ids = (10, 32, 43, 13, 45, 65, 24, 75, 12)
for eid in emp_ids:  # eid e_id empid emp_id
    print("Employee id : ", eid)

stu_nos = (10, 32, 43, 13, 45, 65, 24, 75, 12)  # s_no

for s_no in stu_nos:  # stu_no
    print("Student no : ", s_no)

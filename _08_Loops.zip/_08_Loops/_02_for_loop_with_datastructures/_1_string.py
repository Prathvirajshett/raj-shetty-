'''
for <var> in <sequence>:
    # perform business logic
'''
print("--------For loop with String-------")
msg = ['Hello World', 'mani']

for char in msg:
    print("Character : ", char)

list = ['Peter','Joseph','Ricky','Devansh']
for i in list:
    print("Hello",i)



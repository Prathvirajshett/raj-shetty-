
print("-------For loop with set--------")
set1 = {1, 2, 3, 4, 5, 6}
for val in set1:
    print("Value : ", val)

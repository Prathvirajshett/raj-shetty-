
'''
SETS:
--------
s1 = {1, 2, 3, 7}
s2 = {3, 4, 5, 7}

Union        : s1 ∪ s2  => {1,2,3,4,5,7}
Intersection : s1 ∩ s2  => {3,7}
Minus        : s1 - s2  => {1,2}
               s2 - s1  => {4,5}
               
Venn Diagrams : Check it

'''

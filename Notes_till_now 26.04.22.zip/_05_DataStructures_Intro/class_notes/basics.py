''''''

'''
Mathematically--------
Data types : numbers 
Data structures : Sets, Sequence, Matrices


Data types -  int- 1, float - 1.0, boolean - True, False, str - "True", '1'  
Numbers     Boolean  string"" ''
               int         
               float
               complex
               
               

Data structures - String  List   Tuple  Dictionary  Set

'''
# Data types
# int
x = 10
x = 120
eid = 101
roll_no = 22

print("__data type_____",type(roll_no))

_123 = 123

# float
sal = 12000.43
mobile_bill = 243.67
fuel_bill = 123.45

print(type(fuel_bill))

# Boolean  True/False
is_active = False
is_male = True
is_exists = False
#CRUD

is_ready = True # create
print(is_ready) # Retrieve/Read

is_ready = 10.80  # update

del(is_ready) # delete



print(type(is_active))

# CRUD Operations

# CREATE   - signup,
# RETRIEVE - signin
# UPDATE   - update mobile , name
# DELETE   - delete a mail, delete an entire account


x = 10  # Create

print("Value of x :", x)  # Retrieve
# print('Value of x :', x)  # Retrieve

x = 20  # Update
print('Value of x :', x)  # Retrieve

del x  # Delete

# print("Value of x : ", x)

# DATA STRUCTURES
# String      --> 1 HOURS    '', "12346"
# List        --> 1 HOURS     [1, 2.5, True, "mani" ]
# Tuple       --> 15 minutes  (1, 2, 3)
# Dictionary  --> 1 HOURS    {'name': 'mani','num' : 10 }
# Set         --> 30 Minutes {1, 2, 3}


# String  --> 3 HOURS

name = 'MadhuN'
print(name)  # Dont write in this way
print("Name is : ", name)

message = "Hello World"
print("Message is : ", message)

course = 'Python Programming Language'
print("course is: ",course)

data = 'dsafadfw2r2432$#@$#@@!DSFDSF@!#@!asaSahjk(%iaZR#@$%^TYHGFB'
print(data)


# List  # 2 HOURS
emp_ids = [100, 101, 102, 103, 104, 105]
print("Employee ids : ", emp_ids)

list1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
print("Data : ", list1)

# Tuple   # 15 Minutes
emp_ids = (100, 101, 102, 103, 104, 105)
print("Employee ids : ", emp_ids)

tupl1 = (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
print("Data : ", tupl1)


# Dictionary  # 2-3 HOURS
'''
eat     :  asfdf
example :  to give reference 

word - meaning
key  - value 
'''
e_data = {'eid': 100,
          'name': 'Madhu Nettem',
          'sal': 10000.5,
          'location': 'Bangalore',
          'is_perm': False
          }
print("Dictionary is :", e_data)

# Set   # 30 Minutes
numbers = {1, 2, 3, 4, 5, 6, 7, 8}
print("Set is : ", numbers)









# DATA STRUCTURES



x = 10

print(x)    # returns the data of any passing stmt
print(type(x)) # type() return the data type
print(id(x))    # id(x) returns address
address = id(x)
print(address)


# single line comments

x = True
x = False
print(id(x))
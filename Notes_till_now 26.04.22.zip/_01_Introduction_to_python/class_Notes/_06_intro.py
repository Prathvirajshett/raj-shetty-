'''
In python No need to declare the type of data either it may be numbers like
integer, float, boolean, string

so that python is dynamically typed programming language'''
x = 100
x = 10.5
print(type(x), id(x))
print("-------------------------------")
# output  <class 'int'>


y = "vn2 solutions"
print("Data type of y",type(y))

# output <class 'str'>


z = True
x = False
print(type(x), id(x))
class Myclass():
    pass


class Harsha():
    pass

# a = Myclass()
# print(type(a)) 

# my_varaible = 

# 2harsha =

# harsha@ =  
# PEP8 standard
harsha = 10
Harsha = 20
print(harsha)
if 'python' == "Python":
    print('harsha')
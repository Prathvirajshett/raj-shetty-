''''''

'''
Data types : numbers 
Data structures : Sets, Sequence, Matrices


Data types -  Numbers     Boolean
               int         
               float
               complex

Data structures - String  List   Tuple  Dictionary  Set

'''
# Data types
# int
x = 10
x = 120
eid = 101
roll_no = 22

# float
sal = 12000.43
mobile_bill = 243.67
fuel_bill = 123.45

# Boolean
is_active = False
is_male = True
is_exists = False
is_ready = True

# CRUD Operations

# CREATE
# RETRIEVE
# UPDATE
# DELETE


x = 10  # Create

print("Value of x :", x)  # Retrieve
# print('Value of x :', x)  # Retrieve

x = 20  # Update
print('Value of x :', x)  # Retrieve

del x  # Delete

# print("Value of x : ", x)

# DATA STRUCTURES
# String      --> 3 HOURS
# List        --> 2 HOURS
# Tuple       --> 15 minutes
# Dictionary  --> 2-3 HOURS
# Set         --> 30 Minutes


# String  --> 3 HOURS

name = 'MadhuN'
print(name)  # Dont write in this way
print("Name is : ", name)

message = "Hello World"
print("Message is : ", message)

course = 'Python Programming Language'
print("Course is : ", course)

data = 'dsafadfw2r2432$#@$#@@!DSFDSF@!#@!asaSahjk(%iaZR#@$%^TYHGFB'
print(data)


# List  # 2 HOURS
emp_ids = [100, 101, 102, 103, 104, 105]
print("Employee ids : ", emp_ids)

list1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
print("Data : ", list1)

# Tuple   # 15 Minutes
emp_ids = (100, 101, 102, 103, 104, 105)
print("Employee ids : ", emp_ids)

tupl1 = (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
print("Data : ", tupl1)


# Dictionary  # 2-3 HOURS
'''
eat     :  asfdf
example :  to give reference 

word - meaning
key  - value 
'''
e_data = {'eid': 100,
          'name': 'Madhu Nettem',
          'sal': 10000.5,
          'location': 'Bangalore',
          'is_perm': False
          }
print("Dictionary is :", e_data)

# Set   # 30 Minutes
numbers = {1, 2, 3, 4, 5, 6, 7, 8}
print("Set is : ", numbers)









# DATA STRUCTURES



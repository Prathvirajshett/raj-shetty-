

# pass

# if   elif  else   while   for     function   class  "with stmt"

n1 = 24
if n1 == 10:
    print("Value is 10")
else:
    # pass
    print("Invalid number")

if True:
    pass
else:
    pass

'''
while True:
    pass
'''



# prime numbers

a = 1
while a < 10:
    print(a)
    if a == 3:
        break
    a += 1


# continue statement
print("continue statement")

x = 0
while x < 10:
    x += 1
    if x == 6:
        continue
    print(x)




   











x = 10
y = 1
z = 15
if x < y or y > z:
    print("true")
    if x > y:
        print("false")
    else:
        pass

'''
for <var> in <sequence>:
    # perform business logic
'''
print("--------For loop with String-------")
msg = 'Hello World'

for char in msg:
    print("Character : ", char)

for element in msg:
    print("Character : ", element)

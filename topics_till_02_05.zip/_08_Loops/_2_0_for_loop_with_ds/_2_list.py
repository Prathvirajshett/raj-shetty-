print("--------For loop with list-------")

list1 = [10, 32, 43, 13, 45, 65, 24, 75, 12]
for num in list1:
    print("Number : ", num)

emp_ids = [10, 32, 43, 13, 45, 65, 24, 75, 12]
for eid in emp_ids:  # eid e_id empid emp_id
    print("Employee id : ", eid)


for s_no in [10, 32, 43, 13, 45, 65, 24, 75, 12]:  # stu_no
    print("Student no : ", s_no)

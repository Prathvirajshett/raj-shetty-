# print("sdf"dsaffd) # compilation error
list1 = [1, 2, 3, 4, 5]
# print(list1[10]) # runtime error


str1 = 'hello world * '

print(str1 * 10)





# Decision making : "condition based scenarios" for a particular user
                    # int float bool string list tuple dict set

# Loops : To handle collection of users # multiple users

# REQ: Print given customer value

# DATA TYPES
x = 10

x = int(input("Enter number : "))  # 10
print("The value is : ", x)

x = float(input("Enter number: "))  # 10.5
print("The value is : ", x)

x = bool(input("Enter your decision: "))   # True
print("The value is : ", x)

x = input("Enter message ")  # 'Hello World'
print("The value is : ", x)

x = input("Enter message ")  # 'Hello World'
print("The value is : ", x)

# list,tuple,dict,set
'''
  Why loops : To iterate through collection of elements
              Collection
              # Maths : Sets   Sequence        Matrices
              # Python: String List Tuple Dict Set
'''

# DATA STRUCTURES
msg = 'Hello World' # String
emp_ids = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]  # List
          # [1*1,2*2,3*3,4*4....]
          # [1, 4, 9, 16, 25...]
emp_ids = (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)  # Tuple
e_data = {'eid':100,'name':'MadhuN'}
nums = {1,2,3,4,5}

print(emp_ids)


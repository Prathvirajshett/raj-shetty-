


# rules a creating a va

# str = 'harsha'
# print(str.capitalize())
        
a = (1,2,3,4)
print(a)
b = list(a)
b.append(5)
print(b)
c = tuple(b)
print(c)

tuple = (1,2,3)
print(tuple)
list1 = list(tuple)
list1.append(4)
print(list1)
tup1 = tuple(list1)
# and = 10


word = 'and'
print("Word is : ", word)

di = {'int',float,bool,string}

data = {True: 100,
        'And': 300,
        'Hello': 'and'
        }
print(data)

And = 100
Or = 200
Not = 300
print(And, Or, Not)